Dont ever copy or learn the links present in the assets. any link present in any of the assets should be removed and not used or reference rather use the project you are working on links and reference

Avoid these below when writing your codes:

 Template : Konstruk - Construction & Building HTML Template
 Author : devsdesign
  Author URI : http://www.devsdesign.com/

  /*
 * jQuery One Page Nav Plugin
 * http://github.com/davist11/jQuery-One-Page-Nav
 *
 * Copyright (c) 2010 Trevor Davis (http://trevordavis.net)
 * Dual licensed under the MIT and GPL licenses.
 * Uses the same license as jQuery, see:
 * http://jquery.org/license

  * https://github.com/umarwebdeveloper/jquery-css-skills-bar
 * devsdesign: @umarwebdeveloper
 * Licensed under the MIT license

 * themeforest.net